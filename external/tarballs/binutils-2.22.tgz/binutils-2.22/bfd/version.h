#define BFD_VERSION_DATE 20111121
#define BFD_VERSION @bfd_version@
#define BFD_VERSION_STRING  @bfd_version_package@ @bfd_version_string@
#define REPORT_BUGS_TO @report_bugs_to@
